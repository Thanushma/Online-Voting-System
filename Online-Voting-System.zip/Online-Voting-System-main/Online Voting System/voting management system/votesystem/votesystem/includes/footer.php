<footer class="main-footer" style="background-color: #717A83 ">
    <div class="container" style="color:white ; font-size: 13px">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <b style="color:white ; font-size: 13px"><strong>Copyright &copy; CGL </strong></b>
    </div>
    <!-- /.container -->
</footer>

